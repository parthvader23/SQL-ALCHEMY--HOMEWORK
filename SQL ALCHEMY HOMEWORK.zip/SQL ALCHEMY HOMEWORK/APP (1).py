#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import datetime as dt
import numpy as np
import pandas as pd

import sqlalchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func

from flask import Flask, jsonify

#Database Setup 
engine = create_engine("sqlite:///.Resources/hawaii.sqlite")

Base = automap_base()

Base.prepare(engine, reflect=True)

#save refrence to each table 
Measurement = Base.classes.measurement 
Station = Base.classes.station

#create session link from Python to DB
session = Session(engine)

#flask setup

app = Flask(__name__)

#Flask Routes endpoints

@app.route("/")
def welcome():
    return (
        f"Welcome to the Hawaii Climate Analysis API! <br/>"
        f"Available Routes: <br/>"
        f"/api/v1.0/precipitation<br/>"
        f"/api/v1.0/stations<br/>"
        f"/api/v1.0/tobs<br/>"
        f"/api/v1.0/temp/start/end"
        
        
@app.route("/api/v1.0/preciptitation")
def precipitation():
        #return the precipitation data from last year
        prev_year = dt.date(2017,9,23) - dt.timedelta(days=365)
        
        #query fr the date and percipitation for the last year
        percipitation = session.query(Measurement.date, Measurement.prcp).\
                filter(Measurement.date >= pre.year) .all()
        
        precip = {date: prcp for date, prcp in perciptiation}
        return jsonify(precip)
        
@app.route("/api/1.0/stations")  
        results = session.query(Station.station).all()
        
        stations = list(np.rael(results))
        return jsonify(station)
        
        
        
if __name__ == '__main__':
        app.run()
        

